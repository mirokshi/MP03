/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pt4;

/**
 *
 * @author mirokshi
 */
public class Pt4 {

    /**
     * @param args the command line arguments
     */
//    public static void main(String[] args) {
        // TODO code application logic here
        
//        String s="Hola mundo";
//        
//        s="Algo"+" otra cosa";
//        
//        
//        System.out.println(s.substring(5,8)); //tra
//        
//        
//        String[] trossos=s.split(" ");
//        
//        for (String par:trossos) {
//            System.out.println(par); //Algo\n otra\n cosa\n
//        }
//        
//        for (int i = 0; i < trossos.length; i++) {
//            System.out.println(trossos[i]);//Algo\n otra\n cosa\n
//        }
//        
//         System.out.println(s.lastIndexOf('o',15)); //11
//         
//         
//         System.out.println("Hola"=="Hola"); //true
//         
//         
//         
//         StringBuilder m=new StringBuilder("Hola");
//         
//         System.out.println(m.capacity()); //20
//         
//         m.insert(4, '!');
//         m.insert(1, "ooo");
//         m.append(" Adios!!");
//         m.delete(1, 3);
//         System.out.println(m); //Hoola! Adios!!
//         

//        
//            System.out.println(args.length);
//        
//        System.out.println("1");
//        if (args.length!=0) {
//            System.out.println("2");
//            for (int i = 0; i < args.length; i++) {
//                System.out.println("3");
//                System.out.println(args[i]);
//            }
//        }
//        System.out.println("4");
//        
//    }
//    
}
